export interface IWorkflowHistoryState {
  DatatableItems:any[];  
  Loggedinuserid:number;
  IsAdmin: boolean;
  IsProfessor: boolean;
  
}
