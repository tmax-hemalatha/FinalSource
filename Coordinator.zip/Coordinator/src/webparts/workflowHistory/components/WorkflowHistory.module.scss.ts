/* tslint:disable */
require("./WorkflowHistory.module.css");
const styles = {
  workflowHistory: 'workflowHistory_b3625d87',
  container: 'container_b3625d87',
  row: 'row_b3625d87',
  column: 'column_b3625d87',
  'ms-Grid': 'ms-Grid_b3625d87',
  title: 'title_b3625d87',
  subTitle: 'subTitle_b3625d87',
  description: 'description_b3625d87',
  button: 'button_b3625d87',
  label: 'label_b3625d87'
};

export default styles;
/* tslint:enable */