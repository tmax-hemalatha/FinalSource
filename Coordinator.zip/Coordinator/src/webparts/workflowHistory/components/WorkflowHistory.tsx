import * as React from 'react';
import styles from './WorkflowHistory.module.scss';
import { IWorkflowHistoryProps } from './IWorkflowHistoryProps';
import { escape } from '@microsoft/sp-lodash-subset';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'jquery/dist/jquery.min.js';
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";
import "datatables.net-dt/css/jquery.dataTables.min.css";
import { IWorkflowHistoryState } from './IWorkflowHistoryState';

import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { Web } from '@pnp/sp/webs';
import "@pnp/sp/site-users/web";
import * as $ from 'jquery';
import { sp } from "@pnp/sp";


var spfxdatatable = null;
let arr = [];

const NewWeb = Web('https://tmxin.sharepoint.com/sites/POC/ClientPOC/SUAD/workflowHistory.aspx?env=WebView/');


export default class WorkflowHistory extends React.Component<IWorkflowHistoryProps,IWorkflowHistoryState> {
  public constructor(props: IWorkflowHistoryProps) {
  super(props);
  sp.setup({
    spfxContext: this.props.context
  });

  this.state = {
    DatatableItems: [],
    IsAdmin: false,
    IsProfessor: false,
    Loggedinuserid: null

  }
}

public Currentloggedinuser() {
  NewWeb.currentUser.get().then((user) => {
    let userID = user.Id;
    this.setState({ Loggedinuserid: userID });
  }, (errorResponse) => {

  }
  );
}

public componentDidMount() {

  
  this.Checkuserforlogin();
  this.Currentloggedinuser();
}
public Getadminlistitems() {

  NewWeb.lists.getByTitle("Workflow%20History").items.select("Id", "Title","RequestID","RequestType", "RequestDescription", "Status", "AssignedTo", "RequestedDate", "ActionDate").get()

    .then((items) => {

      if (items.length != 0) {

        this.setState({

          DatatableItems: items

        });
    
      }
    });
}

public async Checkuserforlogin() {

  let groups = await NewWeb.currentUser.groups();

  for (var i = 0; i < groups.length; i++) {
    if (groups[i].Title == "SUAD Admin") {

      this.setState({ IsAdmin: true });
      this.Getadminlistitems();
      break;
    } else {
      this.setState({ IsAdmin: false });
    }

    if (groups[i].Title == "SAUD Professor") {
      this.setState({ IsProfessor: true });

      break;
    } else {
      this.setState({ IsProfessor: false });
    }

  }
}

  public render(): React.ReactElement<IWorkflowHistoryProps> {

    let count = 0;
    let handler = this;

    const DataTableBodycontent: JSX.Element[] = this.state.DatatableItems.map(function (item, key) {
      count++;
      return (
        <tr id={`${key}-row-id`}>
          <td>{count}</td>
          <td>{item.RequestID}</td>
          <td>{item.RequestType}</td>
          <td>{item.RequestDescription}</td>
          <td>{item.Status}</td>
          <td>{item.AssignedTo}</td>
          <td>{item.RequestedDate}</td>
          <td>{item.ActionDate}</td>
       
        </tr>
      );
    });
    return (
      <div className={ styles.workflowHistory }>
        <div className='suad-dashboardtable'>
   
   <table className='table table-big' id="suad-data-table" style={{ width: "100%" }}>
     <thead>
       <tr>
         <th>S.No</th>
         <th>Title</th>
         <th>RequestID</th>
         <th>RequestType</th>
         <th>RequestDescription</th>
         <th>Status</th>
         <th>AssignedTo</th>
         <th>RequestedDate</th>
         <th>ActionDate</th>

       </tr>
     </thead>
     <tbody>
       {DataTableBodycontent}
     </tbody>
   </table>
   </div>

      </div>
    );
  }
}
