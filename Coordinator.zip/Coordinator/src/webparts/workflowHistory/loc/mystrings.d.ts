declare interface IWorkflowHistoryWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'WorkflowHistoryWebPartStrings' {
  const strings: IWorkflowHistoryWebPartStrings;
  export = strings;
}
