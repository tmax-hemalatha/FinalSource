import { ServiceScope, ServiceKey } from "@microsoft/sp-core-library";  
import { ICoordinatorView } from '../components/ICoordinatorView';
import { IDataService } from './IDataService'; 
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';  
import { PageContext } from '@microsoft/sp-page-context';  
 
export class UserProfileService implements IDataService {
    public static readonly serviceKey: ServiceKey<IDataService> = ServiceKey.create<IDataService>('userProfle:data-service', UserProfileService);  
    private _spHttpClient: SPHttpClient;
    private _pageContext: PageContext;  
    private _currentWebUrl: string;  

    constructor(serviceScope: ServiceScope) {  
        serviceScope.whenFinished(() => {  
            // Configure the required dependencies  
            this._spHttpClient = serviceScope.consume(SPHttpClient.serviceKey);
            this._pageContext = serviceScope.consume(PageContext.serviceKey);  
            this._currentWebUrl = this._pageContext.web.absoluteUrl;  
        });  
    }

    public getUserProfileProperties(): Promise<ICoordinatorView> {
        return new Promise<ICoordinatorView>((resolve: (itemId: ICoordinatorView) => void, reject: (error: any) => void): void => {  
            this.readUserProfile()  
              .then((orgChartItems: ICoordinatorView): void => {  
                resolve(this.processUserProfile(orgChartItems));  
              });  
          });
    }

    private readUserProfile(): Promise<ICoordinatorView> {  
        return new Promise<ICoordinatorView>((resolve: (itemId: ICoordinatorView) => void, reject: (error: any) => void): void => {  
          this._spHttpClient.get(`${this._currentWebUrl}/_api/SP.UserProfiles.PeopleManager/getmyproperties`,  
          SPHttpClient.configurations.v1,  
          {  
            headers: {  
              'Accept': 'application/json;odata=nometadata',  
              'odata-version': ''  
            }  
          })  
          .then((response: SPHttpClientResponse): Promise<{ value: ICoordinatorView }> => {  
            return response.json();  
          })  
          .then((response: { value: ICoordinatorView }): void => {  
            //resolve(response.value);  
            var output: any = JSON.stringify(response);  
            resolve(output); 
          }, (error: any): void => {  
            reject(error);  
          });  
        });      
    }  

    private processUserProfile(orgChartItems: any): any { 
        return JSON.parse(orgChartItems);  
    }
}