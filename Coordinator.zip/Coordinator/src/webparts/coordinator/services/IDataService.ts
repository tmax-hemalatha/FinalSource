import { ICoordinatorView } from '../components/ICoordinatorView';

export interface IDataService {  
    getUserProfileProperties: () => Promise<ICoordinatorView>;  
}  