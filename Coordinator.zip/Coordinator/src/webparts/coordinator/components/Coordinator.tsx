import * as React from "react";
import styles from "./Coordinator.module.scss";
import { ICoordinatorProps } from "./ICoordinatorProps";
import { escape } from "@microsoft/sp-lodash-subset";
import { SPComponentLoader } from "@microsoft/sp-loader";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
import "@pnp/sp/presets/all";
import swal from "sweetalert";
import { Web } from "@pnp/sp/webs";
import * as $ from "jquery";
import * as moment from "moment";
import { IDataService } from "../services/IDataService";
import { UserProfileService } from "../services/UserProfileService";

import { SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";
import {
  ServiceScope,
  Environment,
  EnvironmentType,
} from "@microsoft/sp-core-library";

import { ICoordinatorView } from "../components/ICoordinatorView";
import { add } from "lodash";
import { noConflict } from "jquery";

let termcode;
var deptOpts = "";
var CrnOpts = "";
var prog = "";
var AllPAssportAttachmentURL = "";
var CurrentUSERNAME = "";
let RequestorUploadedFiles = [];
let ItemId;
let NewWeb = Web("https://tmxin.sharepoint.com/sites/POC/ClientPOC/SUAD/");

export class CoordinatorView implements ICoordinatorView {
  FirstName: string;
  Department: string;
  Office: string;
  UserProfileProperties: Array<any>;
}

export interface ICoordinatorState {
  CurrentUserName: string;
  CurrentUserDepartment: string;
  MasterID: string;
  currentDateTime: string;
  termcode: string;
  userProfileItems: ICoordinatorView;
  Professorstatus: any[];
  Professorcategory: any[];
  RequestorPassportCopies: any[];
  RequesterPassportOnchangeBindCopy: any[];

}
var RequestorPassportCopies = [];

export default class Coordinator extends React.Component<
  ICoordinatorProps,
  ICoordinatorState
> {
  private dataCenterServiceInstance: IDataService;

  constructor(props: ICoordinatorProps, state: ICoordinatorState) {


    SPComponentLoader.loadCss(`href="http://code.jquery.com/ui/1.8.3/themes/base/jquery-ui.css`);
    SPComponentLoader.loadScript(`http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js`);
    SPComponentLoader.loadScript(`http://code.jquery.com/ui/1.8.3/jquery-ui.js`);




    SPComponentLoader.loadCss(
      `https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css`
    );

    SPComponentLoader.loadCss(
      `https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css`
    );
    SPComponentLoader.loadCss(`https://fonts.googleapis.com`);
    SPComponentLoader.loadCss(`https://fonts.gstatic.com" crossorigin`);
    SPComponentLoader.loadCss(
      `https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet`
    );
    SPComponentLoader.loadScript(
      `https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js`
    );
    SPComponentLoader.loadCss(
      `https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css`
    );

    SPComponentLoader.loadCss(
      `https://tmxin.sharepoint.com/sites/POC/ClientPOC/SUAD/SiteAssets/SUAD%20Assets/css/style.css?v=1.9`
    );
    SPComponentLoader.loadCss(
      `https://tmxin.sharepoint.com/sites/POC/ClientPOC/SUAD/SiteAssets/SUAD%20Assets/css/responsive.css`
    );

    SPComponentLoader.loadScript('https://code.jquery.com/jquery-3.6.0.min.js', {

      globalExportsName: 'jQuery'

    }).then(() => {

      SPComponentLoader.loadScript('https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js', {

        globalExportsName: 'jQuery'

      }).then(($: any) => {

        SPComponentLoader.loadScript('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', {

          globalExportsName: 'jQuery'

        });

      });

    });
    super(props);

    let userProfile: ICoordinatorView = new CoordinatorView();
    userProfile.FirstName = "";
    userProfile.Office = "";

    userProfile.Department = "";
    userProfile.UserProfileProperties = [];
    var RequestorPassportCopies = [];

    let RequesterPassportOnchangeBindCopy = [];

    var ProfessorPhotoDetailsCopies = [];
    this.state = {
      Professorstatus: [],
      Professorcategory: [],
      CurrentUserName: "",
      CurrentUserDepartment: "",
      MasterID: "",
      termcode: "",
      currentDateTime: moment().format("DD/MM/YYYY hh:MM A"),
      userProfileItems: userProfile,
      RequestorPassportCopies: [],
      RequesterPassportOnchangeBindCopy: [],

    };
  }


  public GetProfessorStatus() {
    NewWeb.lists
      .getByTitle("ProfessorStatus")
      .items.select("ID", "Title")
      .get()

      .then((items) => {
        if (items.length != 0) {
          this.setState({
            Professorstatus: items,
          });
        }
      });
  }
  public GetProfessorCategory() {
    NewWeb.lists
      .getByTitle("ProfessorCategory")
      .items.select("ID", "Title")
      .get()

      .then((items) => {
        if (items.length != 0) {
          this.setState({
            Professorcategory: items,
          });
        }
      });
  }
  public CheckforBannerid(Type) {
    var bannerId = $("#txt-BannerId").val();

    //For retrieving Professor term code

    var myHeaders = new Headers();
    myHeaders.append("Accept", "application/vnd.hedtech.integration.v7+json");
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append(
      "Authorization",
      "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImFwaXVzZXIiLCJuYmYiOjE2NDAwNDQ5NjEsImV4cCI6MTY0MDY0OTc2MSwiaWF0IjoxNjQwMDQ0OTYxLCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjUwMTkxIiwiYXVkIjoiaHR0cDovL2xvY2FsaG9zdDo1MDE5MSJ9.rt4hingTjvoaavcXRRWC0X_FANEXB_snELiIoNe2DjM"
    );
    var raw =
      '{"DBSourceName":"GetProfessorInfo",\r\n     "Params":\'[{"FieldName":"ProfessorBannerID" ,"Value":"' +
      bannerId +
      '","Operator":"="}]\'}\r\n';

    fetch("https://apis.sorbonne.ae/SorbonneAPIs/banner/GetData", {
      method: "POST",
      headers: myHeaders,
      body: raw,
      redirect: "follow",
    })
      .then((response) => response.json())
      .then((responseData) => {
        const { data = [] } = responseData;
        var datares = data[0];
        // console.log(datares);
        datares.map((item, index) => {
          //   console.log(datares);

          $("#txt-Term").val(datares[index].TERMCODE);
          var termcode = $("#txt-Term").val();
          // alert(termcode);

          //this.setState({ termcode:termcode });
        });
      });

    //For retrieving Professor Programs

    var myHeaders = new Headers();
    myHeaders.append("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImFwaXVzZXIiLCJuYmYiOjE2NDAxODAxMTcsImV4cCI6MTY0MDc4NDkxNywiaWF0IjoxNjQwMTgwMTE3LCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjUwMTkxIiwiYXVkIjoiaHR0cDovL2xvY2FsaG9zdDo1MDE5MSJ9.-Dqe8KTVRyp5z-bn0m-y8L2LQq6xRczOQ-qNoLEB4VQ");
    myHeaders.append("Content-Type", "application/json");

    var raw = "{\"DBSourceName\":\"filterservice\",\"Params\":'[\r\n {\"FieldName\":\"filtercolumn\" ,\"Value\":\"Program\",\"Operator\":\"=\"}]'}";

    fetch("https://apis.sorbonne.ae/SorbonneAPIs/banner/GetData", {
      method: 'POST',
      body: raw,
      headers: myHeaders,
    })

      .then(response => response.json())
      .then(responseData => {
        console.log("test", responseData)
        const { data = [] } = responseData;
        // console.log("test", data)
        var datares = data[0];


        datares.map((item, index) => {


          prog += `<option value='${datares[index].Description}'>${datares[index].Description}</option>`;

        })

        $("#ddl-Program").html(prog)

        //  this.setState(data)
      }

      );
    //For retrieving Professor personal info

    var myHeaders = new Headers();
    myHeaders.append("Accept", "application/vnd.hedtech.integration.v7+json");
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append(
      "Authorization",
      "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImFwaXVzZXIiLCJuYmYiOjE2NDAwNDQ5NjEsImV4cCI6MTY0MDY0OTc2MSwiaWF0IjoxNjQwMDQ0OTYxLCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjUwMTkxIiwiYXVkIjoiaHR0cDovL2xvY2FsaG9zdDo1MDE5MSJ9.rt4hingTjvoaavcXRRWC0X_FANEXB_snELiIoNe2DjM"
    );

    //var raw = "{\"DBSourceName\":\"GetProfessorInfo\", \"Params\":'[{\"FieldName\":\"PROFESSORBANNERID\" ,\"Value\":\"A00017829\",\"Operator\":\"=\"}, \r\n{\"FieldName\":\"TermCode\" ,\"Value\":\"192020\",\"Operator\":\"=\"}]'}";

    var raw =
      '{"DBSourceName":"GetProfessorInfo", "Params":\'[{"FieldName":"PROFESSORBANNERID" ,"Value":"' +
      bannerId +
      '","Operator":"="}, \r\n{"FieldName":"TermCode" ,"Value":"192020","Operator":"="}]\'}';
    //alert(raw);
    fetch("https://apis.sorbonne.ae/SorbonneAPIs/banner/GetData", {
      method: "POST",
      headers: myHeaders,
      body: raw,
      redirect: "follow",
    })
      .then((response) => response.json())
      .then((responseData) => {
        const { data = [] } = responseData;
        var datares = data[0];
        console.log(datares);
        datares.map((item, index) => {
          console.log(datares);

          $("#txt-FirstName").val(datares[index].FirstName);
          $("#txt-LastName").val(datares[index].LastName);
          $("#txt-PersonalMobileNumber").val(datares[index].PersonalMobileNumber);
          $("#txt-PersonalEmail").val(datares[index].PersonalEmail);
          $("#ddl-Gender").val(datares[index].Gender);
          $("#txt-teachingstartenddate").val(datares[index].TeachingStartDate);
        });
      });
    //Get Course Details
    //  var raw = "{\"DBSourceName\":\"GetProfessorCourses\",\r\n    \"Params\":'[{\"FieldName\":\"ProfessorBannerID\" ,\"Value\":\"" + bannerId + "\",\"Operator\":\"=\"},{\"FieldName\":\"TERMCODE\" ,\"Value\":\"192020\",\"Operator\":\"=\"}]'}";

    var myHeaders = new Headers();
    myHeaders.append("Accept", "application/vnd.hedtech.integration.v7+json");
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append(
      "Authorization",
      "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImFwaXVzZXIiLCJuYmYiOjE2NDAwNDQ5NjEsImV4cCI6MTY0MDY0OTc2MSwiaWF0IjoxNjQwMDQ0OTYxLCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjUwMTkxIiwiYXVkIjoiaHR0cDovL2xvY2FsaG9zdDo1MDE5MSJ9.rt4hingTjvoaavcXRRWC0X_FANEXB_snELiIoNe2DjM"
    );

    var raw =
      '{"DBSourceName":"GetProfessorCourses",\r\n    "Params":\'[{"FieldName":"ProfessorBannerID" ,"Value":"RSHABANEH","Operator":"="},{"FieldName":"TERMCODE" ,"Value":"192020","Operator":"="}]\'}';

    fetch("https://apis.sorbonne.ae/SorbonneAPIs/banner/GetData", {
      method: "POST",
      headers: myHeaders,
      body: raw,
      redirect: "follow",
    })
      .then((response) => response.json())
      .then((responseData) => {
        const { data = [] } = responseData;
        var datares = data[0];
        console.log(datares);
        datares.map((item, index) => {
          console.log(datares);

          CrnOpts += `<option value='${datares[index].CourseName}'>${datares[index].CourseName}</option>`;

          $("#ddl-CRNTitle").html(CrnOpts);
        });
      });

    //Get Departments

    var myHeaders = new Headers();
    myHeaders.append("Accept", "application/vnd.hedtech.integration.v7+json");
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append(
      "Authorization",
      "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImFwaXVzZXIiLCJuYmYiOjE2NDAwNDQ5NjEsImV4cCI6MTY0MDY0OTc2MSwiaWF0IjoxNjQwMDQ0OTYxLCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjUwMTkxIiwiYXVkIjoiaHR0cDovL2xvY2FsaG9zdDo1MDE5MSJ9.rt4hingTjvoaavcXRRWC0X_FANEXB_snELiIoNe2DjM"
    );

    var raw =
      '{"DBSourceName":"filterservice","Params":\'[\r\n {"FieldName":"filtercolumn" ,"Value":"DepartmentCode","Operator":"="}]\'}';

    fetch("https://apis.sorbonne.ae/SorbonneAPIs/banner/GetData", {
      method: "POST",
      headers: myHeaders,
      body: raw,
      redirect: "follow",
    })
      .then((response) => response.json())
      .then((responseData) => {
        const { data = [] } = responseData;
        var datares = data[0];
        console.log(datares);
        datares.map((item, index) => {
          console.log(datares);
          deptOpts += `<option value='${datares[index].Description}'>${datares[index].Description}</option>`;
          $("#ddl-RequestorDepartment").html(deptOpts);
        });
      });

    //  this.setState(data)
  }

  public componentWillMount(): void {
    let serviceScope: ServiceScope = this.props.serviceScope;
    this.dataCenterServiceInstance = serviceScope.consume(
      UserProfileService.serviceKey
    );

    this.dataCenterServiceInstance
      .getUserProfileProperties()
      .then((userProfileItems: ICoordinatorView) => {
        for (
          let i: number = 0;
          i < userProfileItems.UserProfileProperties.length;
          i++
        ) {
          // console.log(userProfileItems.UserProfileProperties[i].Key);
          if (userProfileItems.UserProfileProperties[i].Key == "FirstName") {
            userProfileItems.FirstName =
              userProfileItems.UserProfileProperties[i].Value;
          }

          if (userProfileItems.UserProfileProperties[i].Key == "Department") {
            userProfileItems.Department =
              userProfileItems.UserProfileProperties[i].Value;
          }
          if (userProfileItems.UserProfileProperties[i].Key == "Office") {
            userProfileItems.Office =
              userProfileItems.UserProfileProperties[i].Value;
          }
        }

        this.setState({ userProfileItems: userProfileItems });
      });
  }
  /* public GetCRNInformation(Type) {
     var bannerId = $("#txt-Bannerid").val();
     var term = $("#txt-Term").val();
     //alert("entered");
     //alert(bannerId);
     //alert(term);
 
 
     //For retrieving Professor personal info
 
     var myHeaders = new Headers();
     myHeaders.append("Accept", "application/vnd.hedtech.integration.v7+json");
     myHeaders.append("Content-Type", "application/json");
     myHeaders.append("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImFwaXVzZXIiLCJuYmYiOjE2NDAwNDQ5NjEsImV4cCI6MTY0MDY0OTc2MSwiaWF0IjoxNjQwMDQ0OTYxLCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjUwMTkxIiwiYXVkIjoiaHR0cDovL2xvY2FsaG9zdDo1MDE5MSJ9.rt4hingTjvoaavcXRRWC0X_FANEXB_snELiIoNe2DjM");
 
     //var raw = "{\"DBSourceName\":\"GetProfessorInfo\", \"Params\":'[{\"FieldName\":\"PROFESSORBANNERID\" ,\"Value\":\"A00017829\",\"Operator\":\"=\"}, \r\n{\"FieldName\":\"TermCode\" ,\"Value\":\"192020\",\"Operator\":\"=\"}]'}";
 
     var raw = "{\"DBSourceName\":\"GetProfessorInfo\", \"Params\":'[{\"FieldName\":\"PROFESSORBANNERID\" ,\"Value\":\"" + bannerId + "\",\"Operator\":\"=\"}, \r\n{\"FieldName\":\"TermCode\" ,\"Value\":\"" + term + "\",\"Operator\":\"=\"}]'}";
     //alert(raw);
     fetch('https://apis.sorbonne.ae/SorbonneAPIs/banner/GetData', {
       method: 'POST',
       headers: myHeaders,
       body: raw,
       redirect: 'follow'
 
     })
       .then(response => response.json())
       .then(responseData => {
         const { data = [] } = responseData;
         var datares = data[0];
         console.log(datares);
         datares.map((item, index) => {
           console.log(datares);
 
           $("#txt-FirstName").val(datares[index].FirstName);
           $("#txt-LastName").val(datares[index].LastName);
           $("#txt-PersonalMobileNumber").val(datares[index].PersonalMobileNumber);
           $("#txt-PersonalEmail").val(datares[index].PersonalEmail);
           $("#ddl-Gender").val(datares[index].Gender);
           $("#txt-teachingstartenddate").val(datares[index].TeachingStartDate);
 
         })
 
       })
     //Get Course Details
 
     var myHeaders = new Headers();
     myHeaders.append("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImFwaXVzZXIiLCJuYmYiOjE2MzkyODY0MDksImV4cCI6MTYzOTg5MTIwOSwiaWF0IjoxNjM5Mjg2NDA5LCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjUwMTkxIiwiYXVkIjoiaHR0cDovL2xvY2FsaG9zdDo1MDE5MSJ9.1VUyU-zZTJtodWVEEMWWCJRlzcBotw_DCrYSNbQQoa0");
     myHeaders.append("Content-Type", "application/json");
 
     var raw = "{\"DBSourceName\":\"GetProfessorCourses\",\r\n    \"Params\":'[{\"FieldName\":\"ProfessorBannerID\" ,\"Value\":\"" + bannerId + "\",\"Operator\":\"=\"},{\"FieldName\":\"TERMCODE\" ,\"Value\":\"" + term + "\",\"Operator\":\"=\"}]'}";
 
 
     fetch("https://apis.sorbonne.ae/SorbonneAPIs/banner/GetData", {
       method: 'POST',
       body: raw,
       headers: myHeaders,
     })
       .then(response => response.json())
       .then(responseData => {
         const { data = [] } = responseData;
         var datares1 = data[0];
         console.log(datares1);
         datares1.map((item, index) => {
           console.log(datares1);
 
           CrnOpts += `<option value='${datares1[index].CourseName}'>${datares1[index].CourseName}</option>`;
         })
 
 
         $("#ddl-CRNTitle").html(CrnOpts);
 
       }
       );
 
     //Get Departments
 
     var myHeaders = new Headers();
     myHeaders.append("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImFwaXVzZXIiLCJuYmYiOjE2MzkyODY0MDksImV4cCI6MTYzOTg5MTIwOSwiaWF0IjoxNjM5Mjg2NDA5LCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjUwMTkxIiwiYXVkIjoiaHR0cDovL2xvY2FsaG9zdDo1MDE5MSJ9.1VUyU-zZTJtodWVEEMWWCJRlzcBotw_DCrYSNbQQoa0");
     myHeaders.append("Content-Type", "application/json");
 
     var raw = "{\"DBSourceName\":\"filterservice\",\"Params\":'[\r\n {\"FieldName\":\"filtercolumn\" ,\"Value\":\"DepartmentCode\",\"Operator\":\"=\"}]'}";
 
     var requestOptions = {
       method: 'POST',
       headers: myHeaders,
       body: raw,
       redirect: 'follow'
     };
 
     fetch("https://apis.sorbonne.ae/SorbonneAPIs/banner/GetData", {
       method: 'POST',
       body: raw,
       headers: myHeaders,
     })
       .then(response => response.json())
       .then(responseData => {
         const { data = [] } = responseData;
         var datares = data[0];
         console.log(datares);
         datares.map((item, index) => {
 
           deptOpts += `<option value='${datares[index].Description}'>${datares[index].Description}</option>`;
         })
 
 
         $("#ddl-RequestorDepartment").html(deptOpts);
 
       }
       );
 
 
 
 
     //  this.setState(data)
   }
 */
  public async UploadRequestorPassportFilestoAssets() {
    var fileArr = [];
    RequestorUploadedFiles = [];
    var FileNameGenerated: string;
    var CurrentTime;

    let myfile = (
      document.querySelector(".requestor-file-upload") as HTMLInputElement
    ).files.length;

    for (var j = 0; j < myfile; j++) {
      let fileVal = (
        document.querySelector(".requestor-file-upload") as HTMLInputElement
      ).files[j];
      fileArr.push(fileVal);
    }

    for (var i = 0; i < fileArr.length; i++) {
      //if(i == 0){
      CurrentTime = moment().format("DMYYYYHMS"); //1110202191045
      //}
      var tempfilename = fileArr[i].name.split(".");
      FileNameGenerated =
        tempfilename[0] + "-" + CurrentTime + "." + tempfilename[1] + "";

      await NewWeb.getFolderByServerRelativeUrl(
        this.props.context.pageContext.web.serverRelativeUrl +
        "/RequestorUploads"
      )
        .files.add(FileNameGenerated, fileArr[i], true)
        .then((data) => {
          data.file.getItem().then((item) => {
            AllPAssportAttachmentURL += "" + data.data.ServerRelativeUrl + "|";
            RequestorUploadedFiles.push(data);
            item
              .update({
                RequestSessionMasterID: this.state.MasterID,
                AttachmentSectionTags: "Requestor Passport",
              })
              .then((myupdate) => {
                console.log("File uploaded sucessfully : " + i + "");
              });
          });
        })
        .catch((error) => { });
    }
  }
  public async GenerateMasterID() {
    var MasterID;
    const list = NewWeb.lists
      .getByTitle("AcademiccoordinatorMaster")
      .items.select("ID", "RequestSessionMasterID")
      .top(1)
      .orderBy("Created", false)
      .get()
      .then((items) => {
        if (items.length == 0) {
          MasterID = "POAS-" + moment().format("DDMMYYYYHMS") + "-0000";
        } else {
          let num = parseInt(items[0].ID) + 1;
          MasterID = "POAS-" + moment().format("DDMMYYYYHMS") + "-" + num + "";
        }
        this.setState({
          MasterID: MasterID,

        });
      });

  }
  public GetCurrentUserName() {
    var reactHandler = this;
    $.ajax({
      url: `${this.props.siteurl}/_api/web/currentUser`,
      method: "GET",
      headers: {
        Accept: "application/json; odata=verbose",
      },
      success: function (data) {
        CurrentUSERNAME = data.d.Title;
        reactHandler.setState({
          CurrentUserName: CurrentUSERNAME,
          CurrentUserDepartment: data.d.Department,
        });
      },
      error: function (data) { },
    });
  }

 
  public bootstrapTabControl() {
    var i, items = $('.nav-link'), pane = $('.tab-pane');
    // next
    $('.nexttab').on('click', function () {

      $("#RequestInformation").hide();
      $("#RequestorDetails").hide();
      $("#PassportComments").hide();

      for (i = 0; i < items.length; i++) {
        if ($(items[i]).hasClass('active') == true) {
          break;
        }
      }
      if (i < items.length - 1) {
        // for tab
        $(items[i]).removeClass('active');
        $(items[i + 1]).addClass('active');
        // for pane
        $(pane[i]).removeClass('in show active');
        $(pane[i]).hide();
        $(pane[i + 1]).addClass('in show active');
        $(pane[i + 1]).show();
      }

    });
    // Prev
    $('.prevtab').on('click', function () {
      $("#RequestInformation").hide();
      $("#RequestorDetails").hide();
      $("#PassportComments").hide();

      for (i = 0; i < items.length; i++) {
        if ($(items[i]).hasClass('active') == true) {
          break;
        }
      }
      if (i != 0) {
        // for tab
        $(items[i]).removeClass('active');
        $(items[i - 1]).addClass('active');
        // for pane
        $(pane[i]).removeClass('in show active');
        $(pane[i]).hide();
        $(pane[i - 1]).addClass('in show active');
        $(pane[i + 1]).show();
      }
    });
  }

  public componentDidMount() {

    this.bootstrapTabControl();

    this.GetProfessorStatus();
    this.GetProfessorCategory();
    var reactHandler = this;
    const url: any = new URL(window.location.href);
    url.searchParams.get("ItemID");
    ItemId = url.searchParams.get("ItemID");
    

    reactHandler.GetCurrentUserName();
    if (ItemId == null) {
      this.GenerateMasterID();

    }
    else {
     // this.PrePopulateInformation();
    }

  }

 
  public PrePopulateInformation() {
    const list = NewWeb.lists.getByTitle("AcademiccoordinatorMaster").items.filter(`ID eq ${ItemId}`).get().then((items) => {
      if (items.length != 0) {
        this.setState({
          MasterID: items[0].MasterID,
          CurrentUserName: items[0].CurrentUserName,
          CurrentUserDepartment: items[0].CurrentUserDepartment,
          currentDateTime: moment(items[0].Created).format("DD/MM/YYYY hh:MM A")
        });

        //To Set values to input fields starts
        RequestorPassportCopies = [];

        $("#txt-RequestId").val(items[0].RequestID);
        $("#txt-BannerId").val(items[0].BannerID);
        $("#txt-FirstName").val(items[0].FirstName);
        $("#txt-LastName").val(items[0].LastName);
        $("input[name=inlineRadioOptions]").val(['' + items[0].Gender + '']);

        $("#txt-PersonalMobileNumber").val(items[0].PersonalMobileNumber);
        $("#txt-PersonalEmail").val(items[0].PersonalEmail);
        $("#txt-Term").val(items[0].Term);
        $("#ddl-CRNTitle").val(items[0].CRNTitle);
        $("#ddl-Program").val(items[0].Program);
        $("#txt-teachingstartenddate").val(items[0].TeachingStartEndDate);

     
        $("#txt-StaffId").val(items[0].StaffID);
        $("#txt-RequestorComments").val(items[0].RequestorComments);
        $("#txt-Department").val(items[0].ProfessorDepartment);

        //var ExpiryDateNationalID = $("#dte-ExpiryDateNational").val(moment(items[0].ExpiryDateNationalID).format('YYYY-MM-DD'));
        if (items[0].RequestorAttachments != null || items[0].RequestorAttachments != "" || items[0].RequestorAttachments != "undefined") {
          let RequestorPassportCopiesTemp = items[0].RequestorAttachments.split("|");
          for (var i = 0; i < RequestorPassportCopiesTemp.length - 1; i++) {
            RequestorPassportCopies.push(RequestorPassportCopiesTemp[i]);
          }
        }
        this.setState({
          RequestorPassportCopies: RequestorPassportCopies
        });


      }
    });
  }
  public CoordinatorValidation() {
    var Formstatus = false;
    var ErrorMsg = "";
    $("#divErrorText").empty();
    var Bannerno = $("#txt-BannerId").val();
    var Firstname = $("#txt-FirstName").val();
    var LastName = $("#txt-LastName").val();
    var Gender = $("#ddl-Gender").val();
    var PersonalMobileNumber = $("#txt-PersonalMobileNumber").val();
    var PersonalEmail = $("#txt-PersonalEmail").val();
    var Term = $("#txt-Term").val();
    var ProfessorStatus = $("#ddl-professsorstatus").val();
    var Category = $("#ddl-Category").val();
    var RequestorComments = $("#txt-RequestorComments").val();
    var ProfessorDepartment = $("#ddl-RequestorDepartment").val();
    var CRNtitle = $("#ddl-CRNTitle").val();
    var attachfupload = document.getElementById("requestor-file-upload");
    var Program = $("#ddl-Program").val();

    if (Bannerno == "") {
      ErrorMsg = "Please Enter the Banner ID";
      Formstatus = true;
    } else if (Formstatus == false && Firstname == "") {
      ErrorMsg = "Please Enter the First Name";
      Formstatus = true;
    } else if (Formstatus == false && LastName == "") {
      ErrorMsg = "Please Enter the Last Name";
      Formstatus = true;
    } else if (Formstatus == false && Gender == "") {
      ErrorMsg = "Please Select Gender";
      Formstatus = true;
    } else if (Formstatus == false && PersonalMobileNumber == "") {
      ErrorMsg = "Please Enter Mobile Number";
      Formstatus = true;
    } else if (Formstatus == false && PersonalEmail == "") {
      ErrorMsg = "Please Enter PersonalEmail";
      Formstatus = true;
    } else if (Formstatus == false && Term == "") {
      ErrorMsg = "Please Select Term";
      Formstatus = true;
    } else if (Formstatus == false && CRNtitle == "") {
      ErrorMsg = "Please Select CRNTitle";
      Formstatus = true;
      /* } else if(Formstatus==false &&  TeachingDate==""){
        ErrorMsg = "Please Select CRNTitle";
        Formstatus = true*/
    } else if (Formstatus == false && Program == "") {
      ErrorMsg = "Please Select Program";
      Formstatus = true;
    } else if (Formstatus == false && ProfessorStatus == "") {
      ErrorMsg = "Please Select ProfessorStatus";
      Formstatus = true;
    } else if (Formstatus == false && Category == "") {
      ErrorMsg = "Please Select Category";
      Formstatus = true;
    } else if (Formstatus == false && RequestorComments == "") {
      ErrorMsg = "Please Enter Comments";
      Formstatus = true;
    } else if (Formstatus == false && ProfessorDepartment == "") {
      ErrorMsg = "Please Select Department";
      Formstatus = true;
   
  }

    if (Formstatus) {
      $("#divErrorText").append(ErrorMsg);
      $("#divErrorText").show();
      return false;
    } else {
      $("#divErrorText").empty();
      $("#divErrorText").hide();
      return true;
    }
  }

  public SaveCRNInformation(ItemID) {
    var CRNTitle = $("#ddl-CRNTitle").val();
    var pgm = $("#ddl-Program").val();
    var teachingstartdate = $("#txt-teachingstartenddate").val();
    NewWeb.lists.getByTitle("CRNInformation").items.add({
      Title: "CRN Information",
      CRNTitle: CRNTitle,
      Program: pgm,
      TeachingStartEndDate: teachingstartdate,
      RequestNo: this.state.MasterID
    }).then(() => {

    });
  }
  public AddtoList() {
    if (this.CoordinatorValidation()) {
      swal({
        text: "Please wait!",
        button: false,
        closeOnClickOutside: false,
      } as any);

      this.UploadRequestorPassportFilestoAssets();

      var RequestorName = $("#txt-RequestorName").val();
      var BannerID = $("#txt-BannerId").val();
      var FirstName = $("#txt-FirstName").val();
      var LastName = $("#txt-LastName").val();
      var Gender = $("#ddl-Gender").val();
      var PersonalMobileNumber = $("#txt-PersonalMobileNumber").val();
      var PersonalEmail = $("#txt-PersonalEmail").val();
      var Term = $("#txt-Term").val();
      var ProfessorStatus = $("#ddl-professsorstatus").val();
      var Category = $("#ddl-Category").val();
      var RequestID = $("#txt-RequestId").val();
      var StaffID = $("#txt-StaffId").val();
      var RequestorComments = $("#txt-RequestorComments").val();
      var ProfessorDepartment = $("#ddl-RequestorDepartment").val();
      var RequestorDepartment = $("#txt-Department").val();
      var SubmissionDate = this.state.currentDateTime;

      var Requestsessionid = $("#txt-RequestId").val();

      // console.log(ProfessorStatus);
      //console.log(Category)

      setTimeout(() => {
        NewWeb.lists
          .getByTitle("AcademiccoordinatorMaster")
          .items.add({
            Title:"Requestor Information",
            RequestorName: RequestorName,
            BannerID: BannerID,
            FirstName: FirstName,
            LastName: LastName,
            Gender: Gender,
            PersonalMobileNumber: PersonalMobileNumber,
            PersonalEmail: PersonalEmail,
            Term: Term,
            ProfessorDepartment: ProfessorDepartment,
            RequestID: this.state.MasterID,
            StaffID: StaffID,
            SubmissionDate: SubmissionDate,
            RequestSessionMasterID: this.state.MasterID,
            RequestorComments: RequestorComments,
            RequestorDepartment: RequestorDepartment,
            RequestorAttachments: AllPAssportAttachmentURL,
            OverallApprovalStatus: "Pending",
            RequestorStatus:"Submitted",
            ProfessorStatusId: parseInt(ProfessorStatus as any),
            ProfessorCategoryId: parseInt(Category as any)

          })
          .then((item) => {
            let ID = item.data.Id;

            // MasterID: ItemID      

            this.SaveCRNInformation(ID);

            swal({
              text: "Requestor Details added  ",
              icon: "success",
              closeOnClickOutside: false,
            }).then(() => {
              location.reload();
            });

          });
      }, 2000);
    }
    //this.PrePopulateInformation();
  }

  public BindRequestorsPassportSelectedAttachments() {
    const file = (
      document.querySelector(".requestor-file-upload") as HTMLInputElement
    ).files[0];
    const reader = new FileReader();

    reader.addEventListener(
      "load",
      function () {
        $("#RequesterPassportOnchangeBindCopy").append(`<div class="file-img">
  <ul class="nav nav-pills">
      <li><img src="${reader.result}" alt="image" class="attachment-img" /> </li>
      <li class="word-data"><p class="asset-info-header">${file.name}</p><p></p></li>
  </ul>
  <div class="close-doc-img"><img src="https://tmxin.sharepoint.com/sites/POC/ClientPOC/SUAD/SiteAssets/SUAD%20Assets/images/close (3).png" alt="close-icon" class="close-image" /></div>
</div>`);
      },
      false
    );

    if (file) {
      reader.readAsDataURL(file);
    }
  }
  public myFunction() {
    var x = document.getElementById("#btn-prev");
    if (x.style.display === "none") {
      x.style.display = "block";
    } else {
      x.style.display = "block";
    }
  }
  public render(): React.ReactElement<ICoordinatorProps> {
    var handler = this;
    const RequestPassportAttchments: JSX.Element[] = handler.state.RequestorPassportCopies.map(function (item, key) {
      var Name = item.split("/");
      Name = Name[Name.length - 1];
      return (
        <div className="file-img">
          <ul className="nav nav-pills">
            <li><img src={`${item}`} alt="image" className="attachment-img" /> </li>
            <li className="word-data"><p className="asset-info-header">{Name}</p><p></p></li>
          </ul>
          <div className="close-doc-img"><img src="https://tmxin.sharepoint.com/sites/POC/ClientPOC/SUAD/SiteAssets/SUAD%20Assets/images/close (3).png" alt="close-icon" className="close-image" /></div>
        </div>
      );
    });
    const ProfessorstatusJSX: JSX.Element[] = this.state.Professorstatus.map(
      function (item, key) {
        return <option value={item.ID}>{item.Title}</option>;
      }
    );
    const ProfessorcategoryJSX: JSX.Element[] =
      this.state.Professorcategory.map(function (item, key) {
        return <option value={item.ID}>{item.Title}</option>;
      });
    return (
      <div className={styles.coordinator} >
        <div className={styles.container}>
          <div className="container-wrap">
            <div className="banner-wrap">
              <div>
                <img
                  className="banner-img"
                  src="https://tmxin.sharepoint.com/sites/POC/ClientPOC/SUAD/SiteAssets/SUAD%20Assets/images/banner-img.png"
                  alt="banner-img"
                />
                <div className="hero-header-text">
                  <div className="centered banner-text">
                    Professor On Assignment -Onboarding
                  </div>
                </div>
              </div>
            </div>
            <div className="sub-section">
              <div className=" progress-part clearfix">
                <div className="container">
                  <div className="left step-progress-bar">
                    <div className="stepper-wrapper">
                      <div className="stepper-item completed">
                        <div className="step-counter step-processing-border">
                          <img src="https://tmxin.sharepoint.com/sites/POC/ClientPOC/SUAD/SiteAssets/SUAD%20Assets/images/check.png" />
                        </div>
                        <div className="step-name">Submitted</div>
                      </div>
                      <div className="stepper-item">
                        <div className="step-counter step-processing-border"></div>
                        <div className="step-name">Professor</div>
                      </div>
                      <div className="stepper-item">
                        <div className="step-counter"></div>
                        <div className="step-name">Finance</div>
                      </div>
                      <div className="stepper-item">
                        <div className="step-counter"></div>
                        <div className="step-name">Academic Coordinator</div>
                      </div>
                      <div className="stepper-item">
                        <div className="step-counter"></div>
                        <div className="step-name">EA For Management</div>
                      </div>
                      <div className="stepper-item">
                        <div className="step-counter"></div>
                        <div className="step-name">Completed</div>
                      </div>
                    </div>
                  </div>
                  <div className="right-content-info clearfix">
                    <div className="right submit-date">
                      <div className="req-id">
                        <p className="font-color">Submission Date</p>
                        <p>{this.state.currentDateTime}</p>
                      </div>
                    </div>
                    <div className="right req_id">
                      <div className="date-time-info">
                        <p className="font-color">Request ID</p>
                        <p>{this.state.MasterID}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="container">

             
              </div>

              <div className="container clearfix">
                <div className="left-div">
                  <div className="side-bar">
                    <div
                      className="nav flex-column nav-pills"
                      id="ui-tabs"
                      role="tablist" aria-orientation="vertical">

                      {/* <ul>
                        <li>
                          <a
                            className="nav-link"
                            href="#tabs-1"
                          >
                            Request Information
                          </a>
                        </li>
                        <li className="RequestedTab">
                          <a
                            className="nav-link"
                            href="#tabs-2"
                          >
                            Requestor Details
                          </a>
                        </li>
                        <li className="RequestedTab">
                          <a
                            className="nav-link"
                            href="#tabs-3"
                          >
                            Passport and Comments
                          </a>
                        </li>
                      </ul> */}

                      <ul className="nav nav-tabs" id="myTab" role="tablist">
                        <li className="nav-item">
                          <a className="nav-link active" id="RequestInformation-tab" data-toggle="tab" href="#RequestInformation" role="tab" aria-controls="RequestInformation" aria-selected="true">Request Information</a>
                        </li>
                        <li className="nav-item">
                          <a className="nav-link" id="RequestorDetails-tab" data-toggle="tab" href="#RequestorDetails" role="tab" aria-controls="RequestorDetails" aria-selected="false">Requestor Details</a>
                        </li>
                        <li className="nav-item">
                          <a className="nav-link" id="PassportComments-tab" data-toggle="tab" href="#PassportComments" role="tab" aria-controls="PassportComments" aria-selected="false">Passport and Comments</a>
                        </li>
                      </ul>

                    </div>
                  </div>
                </div>

                <div className="right-div">
                  <div id="v-pills-tabContent">
                    <div className="right-body-wrap">
                      <div className="topnav" id="myTopnav">
                        <a href="#" className="active">
                          Requestor
                        </a>
                      </div>
                    </div>

                    <div className="tab-pane fade in active" id="RequestInformation" role="tabpanel" aria-labelledby="RequestInformation-tab">
                      <div className="form-section">
                        <div className="row">
                          <div className="col-md-4">
                            <div className="form-group relative">
                              <input
                                type="text"
                                className="form-control"
                                id="txt-RequestorName"
                                value={this.state.userProfileItems.FirstName}
                              />

                              <span className="floating-label ">
                                Requestor Name
                              </span>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group relative">
                              <input
                                type="text"
                                className="form-control"
                                id="txt-StaffId"
                                value={this.state.userProfileItems.Office}
                              />

                              <span className="floating-label ">Staff ID</span>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group relative">
                              <input
                                type="text"
                                className="form-control"
                                id="txt-Department"
                                value={this.state.userProfileItems.Department}
                              />

                              <span className="floating-label ">
                                Department
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="tab-pane fade" id="RequestorDetails" role="tabpanel" aria-labelledby="RequestorDetails-tab" style={{display:"none"}}>

                      <div className="form-body">
                        <div className="form-section">
                          <div className="row">
                            <div className="col-md-4">
                              <div className="form-group required relative">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="txt-BannerId"
                                  onChange={() =>
                                    this.CheckforBannerid(
                                      $("#txt-BannerId").val()
                                    )
                                  }
                                />

                                <span className="floating-label ">
                                  Banner ID
                                  </span>
                              </div>
                            </div>
                            <div className="col-md-4">
                              <div className="form-group relative">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="txt-FirstName"
                                  autoComplete="off"
                                />
                                <span className="floating-label ">
                                  First Name
                                  </span>
                              </div>
                            </div>
                            <div className="col-md-4">
                              <div className="form-group relative">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="txt-LastName"
                                  autoComplete="off"
                                />
                                <span className="floating-label">
                                  Last Name
                                  </span>
                              </div>
                            </div>
                          </div>
                          <div className="row">
                            <div className="col-md-4">
                              <div className="form-group relative">
                                <div className="chk_box">
                                  <input
                                    className="form-check-input"
                                    type="radio"
                                    name="inlineRadioOptions"
                                    checked
                                    id="ddl-Gender"
                                    value="Male"
                                  />
                                    Male
                                    <input
                                    className="form-check-input"
                                    type="radio"
                                    name="inlineRadioOptions"
                                    checked
                                    id="ddl-Gender"
                                    value="Female"
                                  />
                                    Female
                                  </div>
                                <span className="floating-label chk_box_label ">
                                  Gender
                                  </span>
                              </div>
                            </div>
                            <div className="col-md-4">
                              <div className="form-group relative">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="txt-PersonalMobileNumber"
                                  autoComplete="off"
                                />

                                <span className="floating-label ">
                                  Personal Mobile Number
                                  </span>
                              </div>
                            </div>
                            <div className="col-md-4">
                              <div className="form-group required relative">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="txt-PersonalEmail"
                                  autoComplete="off"
                                />

                                <span className="floating-label ">
                                  Personal Email
                                  </span>
                              </div>
                            </div>
                          </div>
                          <div className="row">
                            <div className="col-md-4">
                              <div className="form-group required relative">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="txt-Term"
                                />

                                <span className="floating-label ">Term</span>
                              </div>
                            </div>
                            <div className="col-md-4">
                              <div className="form-group required relative">
                                <select
                                  name=""
                                  id="ddl-CRNTitle"
                                  className="form-control"
                                ></select>
                                <span className="floating-label ">
                                  CRN Title
                                  </span>
                              </div>
                            </div>
                            <div className="col-md-4">
                              <div className="form-group required relative">
                                <select
                                  name=""
                                  id="ddl-Program"
                                  className="form-control"
                                >
                                  <option value="">--Select a value--</option>


                                </select>
                                <span className="floating-label ">
                                  Program
                                  </span>
                              </div>
                            </div>
                          </div>
                          <div className="row">
                            <div className="col-md-4">
                              <div className="form-group  relative">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="txt-teachingstartenddate"
                                  autoComplete="off"
                                />
                                <a href="#">
                                  <img
                                    src="https://tmxin.sharepoint.com/sites/POC/ClientPOC/SUAD/SiteAssets/SUAD%20Assets/images/calendar.png"
                                    className="calendar-img"
                                  />
                                </a>
                                <span className="floating-label">
                                  Teaching
                                    <span className="label-description">
                                    (Start Date - End Date)
                                    </span>
                                </span>
                              </div>
                            </div>
                            <div className="col-md-4">
                              <div className="form-group  relative">
                                <select
                                  name=""
                                  id="ddl-RequestorDepartment"
                                  className="form-control"
                                ></select>
                                <span className="floating-label ">
                                  Department
                                  </span>
                              </div>
                            </div>
                            <div className="col-md-4">
                              <div className="form-group required relative">
                                <select
                                  name=""
                                  id="ddl-professsorstatus"
                                  className="form-control">
                                  <option value="">--Select a value--</option>
                                  {ProfessorstatusJSX}
                                </select>
                                <span className="floating-label ">
                                  Professor Status
                                  </span>
                              </div>
                            </div>
                          </div>
                          <div className="row">
                            <div className="col-md-4">
                              <div className="form-group relative">

                                <select name="" id="ddl-Category" className="form-control">
                                  <option value="">-Select a value-</option>
                                  {ProfessorcategoryJSX}
                                </select>
                                <span className="floating-label ">
                                  Category
                                  </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                    </div>

                    <div className="tab-pane fade" id="PassportComments" role="tabpanel" aria-labelledby="PassportComments-tab" style={{display:"none"}}>

                      <div className="form-section">
                        <div className="tab_3">
                          <div className="label-file">
                            <label>Passport Attachment</label>
                            <label className="float-right">
                              Note: Please upload both first and second page
                              if applicable
                              </label>
                          </div>

                          <div className="image-upload">
                            <label
                              htmlFor="file-input"
                              className="img-upload"
                            >
                              <img
                                src="https://tmxin.sharepoint.com/sites/POC/ClientPOC/SUAD/SiteAssets/SUAD%20Assets/images/upload.png"
                                className="upload_file"
                              />
                              <h5>Choose an file or drag it here.</h5>
                            </label>

                            <input
                              id="file-input"
                              multiple
                              className="requestor-file-upload"
                              name="requestor-file-upload"
                              type="file"
                              onChange={() => {
                                this.BindRequestorsPassportSelectedAttachments();
                              }}
                            />
                          </div>
                          <div id="RequesterPassportOnchangeBindCopy"></div>
                        </div>

                        <div className="comment-box">
                          <p className="Comments-head">Requestor Comments</p>
                          <textarea
                            className="text-area"
                            id="txt-RequestorComments"
                            rows={5}
                            cols={50}
                            name="comment"
                            form="usrform"
                          ></textarea>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>


                <div className="row content-btn-wrap clearfix">
                  <div
                    className="alert alert-danger"
                    role="alert"
                    id="divErrorText"
                    style={{ display: "none" }}
                  ></div>

                  <div className="tool_box_btn btn-1" id="btn-prev">
                    {/* <button className="btn btn-prev  btn-all" onClick={() => this.PrevFunc("-1")} id="tab2" value="-1">
                      <img
                        src="https://tmxin.sharepoint.com/sites/POC/ClientPOC/SUAD/SiteAssets/SUAD%20Assets/images/prev.png"
                        className="prev-img"
                      />
                      Prev
                    </button> */}
                    <button className="prevtab btn btn-primary">Prev</button>
                  </div>
                  <div className="btn-2">
                    <div className="tool_box_btn">
                      <button
                        className="btn btn-submit btn-all"
                        onClick={() => this.AddtoList()}
                      >
                        Submit
                      </button>
                    </div>
                    <div className="tool_box_btn">
                      <button className="btn btn-draft btn-all">
                        Save as Draft
                      </button>
                    </div>
                  </div>

                  <div className="tool_box_btn btn-3">
                    {/* <button className="btn btn-next btn-all" id="tab1" onClick={() => this.NextFunc("1")} value="1">
                      Next
                      <img
                        src="https://tmxin.sharepoint.com/sites/POC/ClientPOC/SUAD/SiteAssets/SUAD%20Assets/images/next.png"
                        className="next-img"
                      />
                    </button> */}
                    <button className="nexttab btn btn-danger">Next</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

