import { WebPartContext } from "@microsoft/sp-webpart-base";
import { ServiceScope } from '@microsoft/sp-core-library';
export interface ICoordinatorProps {
  siteurl:string;
  description: string;
  context: WebPartContext; 
  userName: string;
  serviceScope: ServiceScope;
}
