export interface ICoordinatorView {
  FirstName: string;
  Department: string;
  Office:string;
  UserProfileProperties: Array<any>;
}