/* tslint:disable */
require("./Coordinator.module.css");
const styles = {
  coordinator: 'coordinator_e567ffc0',
  container: 'container_e567ffc0',
  row: 'row_e567ffc0',
  column: 'column_e567ffc0',
  'ms-Grid': 'ms-Grid_e567ffc0',
  title: 'title_e567ffc0',
  subTitle: 'subTitle_e567ffc0',
  description: 'description_e567ffc0',
  button: 'button_e567ffc0',
  label: 'label_e567ffc0'
};

export default styles;
/* tslint:enable */