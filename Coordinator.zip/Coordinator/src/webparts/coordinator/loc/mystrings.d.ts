declare interface ICoordinatorWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CoordinatorWebPartStrings' {
  const strings: ICoordinatorWebPartStrings;
  export = strings;
}
