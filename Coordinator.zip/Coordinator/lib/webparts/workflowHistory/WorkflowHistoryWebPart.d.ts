import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IWorkflowHistoryWebPartProps {
    description: string;
}
export default class WorkflowHistoryWebPart extends BaseClientSideWebPart<IWorkflowHistoryWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=WorkflowHistoryWebPart.d.ts.map