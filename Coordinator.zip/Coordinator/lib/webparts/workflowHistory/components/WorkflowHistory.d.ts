import * as React from 'react';
import { IWorkflowHistoryProps } from './IWorkflowHistoryProps';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'jquery/dist/jquery.min.js';
import "datatables.net-dt/js/dataTables.dataTables";
import "datatables.net-dt/css/jquery.dataTables.min.css";
import { IWorkflowHistoryState } from './IWorkflowHistoryState';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/site-users/web";
export default class WorkflowHistory extends React.Component<IWorkflowHistoryProps, IWorkflowHistoryState> {
    constructor(props: IWorkflowHistoryProps);
    Currentloggedinuser(): void;
    componentDidMount(): void;
    Getadminlistitems(): void;
    Checkuserforlogin(): Promise<void>;
    render(): React.ReactElement<IWorkflowHistoryProps>;
}
//# sourceMappingURL=WorkflowHistory.d.ts.map