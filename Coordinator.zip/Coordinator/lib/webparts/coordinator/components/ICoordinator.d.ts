export interface ICoordinator {
    FirstName: string;
    DisplayName: string;
    Department: string;
    PictureURL: string;
    UserProfileProperties: Array<any>;
}
//# sourceMappingURL=ICoordinator.d.ts.map