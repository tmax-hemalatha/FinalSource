import * as React from "react";
import { ICoordinatorProps } from "./ICoordinatorProps";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
import "@pnp/sp/presets/all";
import { ICoordinatorView } from "../components/ICoordinatorView";
export declare class CoordinatorView implements ICoordinatorView {
    FirstName: string;
    Department: string;
    Office: string;
    UserProfileProperties: Array<any>;
}
export interface ICoordinatorState {
    CurrentUserName: string;
    CurrentUserDepartment: string;
    MasterID: string;
    currentDateTime: string;
    termcode: string;
    userProfileItems: ICoordinatorView;
    Professorstatus: any[];
    Professorcategory: any[];
    RequestorPassportCopies: any[];
    RequesterPassportOnchangeBindCopy: any[];
}
export default class Coordinator extends React.Component<ICoordinatorProps, ICoordinatorState> {
    private dataCenterServiceInstance;
    constructor(props: ICoordinatorProps, state: ICoordinatorState);
    GetProfessorStatus(): void;
    GetProfessorCategory(): void;
    CheckforBannerid(Type: any): void;
    componentWillMount(): void;
    UploadRequestorPassportFilestoAssets(): Promise<void>;
    GenerateMasterID(): Promise<void>;
    GetCurrentUserName(): void;
    bootstrapTabControl(): void;
    componentDidMount(): void;
    PrePopulateInformation(): void;
    CoordinatorValidation(): boolean;
    SaveCRNInformation(ItemID: any): void;
    AddtoList(): void;
    BindRequestorsPassportSelectedAttachments(): void;
    myFunction(): void;
    render(): React.ReactElement<ICoordinatorProps>;
}
//# sourceMappingURL=Coordinator.d.ts.map