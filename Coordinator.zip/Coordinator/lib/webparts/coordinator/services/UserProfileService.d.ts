import { ServiceScope, ServiceKey } from "@microsoft/sp-core-library";
import { ICoordinatorView } from '../components/ICoordinatorView';
import { IDataService } from './IDataService';
export declare class UserProfileService implements IDataService {
    static readonly serviceKey: ServiceKey<IDataService>;
    private _spHttpClient;
    private _pageContext;
    private _currentWebUrl;
    constructor(serviceScope: ServiceScope);
    getUserProfileProperties(): Promise<ICoordinatorView>;
    private readUserProfile;
    private processUserProfile;
}
//# sourceMappingURL=UserProfileService.d.ts.map